'use strict';

const express = require('express');
const crypto = require('crypto');
const { db, getThresholds, getIntervals } = require('../db');
const { evaluateEvent } = require('../rules');
const { rateLimit } = require('../rate-limit');
const { sendAlertEmail } = require('../email');

const router = express.Router();

const SEVERITIES = new Set(['info', 'low', 'medium', 'high', 'critical']);
const MAX_BATCH = 200;

// ---------------------------------------------------------------------------
// POST /api/v1/enroll  (no bearer auth; enroll key gate)
// ---------------------------------------------------------------------------
router.post('/enroll', rateLimit({ windowMs: 10 * 60 * 1000, max: 10, prefix: 'enroll' }), (req, res) => {
  const body = req.body || {};
  const enrollKey = typeof body.enroll_key === 'string' ? body.enroll_key.trim() : '';
  if (!enrollKey) return res.status(403).json({ error: 'invalid_enroll_key' });

  const key = db.prepare('SELECT id, org_id FROM enroll_keys WHERE key = ? AND active = 1').get(enrollKey);
  if (!key) return res.status(403).json({ error: 'invalid_enroll_key' });

  const token = crypto.randomBytes(24).toString('hex'); // 48 hex chars
  const info = db.prepare(`
    INSERT INTO devices (token, hostname, os, arch, agent_version, ip, status, enrolled_at, last_seen, org_id)
    VALUES (?, ?, ?, ?, ?, ?, 'online', datetime('now'), datetime('now'), ?)
  `).run(
    token,
    String(body.hostname || 'unknown').slice(0, 255),
    String(body.os || '').slice(0, 64),
    String(body.arch || '').slice(0, 32),
    String(body.agent_version || '').slice(0, 32),
    req.ip || '',
    key.org_id || null
  );

  return res.status(201).json({ device_id: info.lastInsertRowid, device_token: token });
});

// ---------------------------------------------------------------------------
// POST /api/v1/lead  (public; landing page early-access form)
// ---------------------------------------------------------------------------
const LEAD_RATE_LIMIT = 5;
const LEAD_RATE_WINDOW_MS = 60 * 60 * 1000; // 1 hour
const leadRate = new Map(); // ip -> [timestamps]

function leadRateLimited(ip) {
  const now = Date.now();
  const hits = (leadRate.get(ip) || []).filter((t) => now - t < LEAD_RATE_WINDOW_MS);
  if (hits.length >= LEAD_RATE_LIMIT) {
    leadRate.set(ip, hits);
    return true;
  }
  hits.push(now);
  leadRate.set(ip, hits);
  // Cheap cleanup: prune stale IPs occasionally.
  if (Math.random() < 0.01) {
    for (const [k, v] of leadRate) {
      const fresh = v.filter((t) => now - t < LEAD_RATE_WINDOW_MS);
      if (fresh.length === 0) leadRate.delete(k);
      else leadRate.set(k, fresh);
    }
  }
  return false;
}

function leadClientIp(req) {
  // Behind Cloudflare the socket/XFF hop is a rotating CF edge IP;
  // CF-Connecting-IP carries the real client address.
  return req.get('cf-connecting-ip') || req.get('x-real-ip') || req.ip || '';
}

router.post('/lead', (req, res) => {
  const ip = leadClientIp(req);
  if (leadRateLimited(ip)) {
    return res.status(429).json({ error: 'rate_limited' });
  }

  const body = req.body || {};
  const email = typeof body.email === 'string' ? body.email.trim().slice(0, 255) : '';
  if (!email || !email.includes('@') || !email.includes('.')) {
    return res.status(400).json({ error: 'invalid_email' });
  }

  const clean = (v) => (typeof v === 'string' ? v.trim().slice(0, 255) : '');
  const name = clean(body.name);
  const company = clean(body.company);
  const message = clean(body.message);

  db.prepare(`
    INSERT INTO leads (email, name, company, message, source, ip)
    VALUES (?, ?, ?, ?, 'landing', ?)
  `).run(email, name, company, message, ip);

  return res.status(201).json({ success: true });
});

// ---------------------------------------------------------------------------
// Bearer device-token auth for everything below
// ---------------------------------------------------------------------------
function deviceAuth(req, res, next) {
  const header = req.get('authorization') || '';
  const m = header.match(/^Bearer\s+(.+)$/i);
  if (!m) return res.status(401).json({ error: 'unauthorized' });
  const device = db.prepare('SELECT * FROM devices WHERE token = ?').get(m[1].trim());
  if (!device) return res.status(401).json({ error: 'unauthorized' });
  req.device = device;
  next();
}

router.use(deviceAuth);

// ---------------------------------------------------------------------------
// POST /api/v1/heartbeat
// ---------------------------------------------------------------------------
router.post('/heartbeat', (req, res) => {
  const body = req.body || {};
  const cpu = Number.isFinite(Number(body.cpu_pct)) ? Number(body.cpu_pct) : null;
  const mem = Number.isFinite(Number(body.mem_pct)) ? Number(body.mem_pct) : null;
  const uptime = Number.isFinite(Number(body.uptime_s)) ? Math.floor(Number(body.uptime_s)) : null;
  const agentVersion = typeof body.agent_version === 'string' ? body.agent_version.slice(0, 32) : null;

  db.prepare(`
    UPDATE devices
    SET last_seen = datetime('now'),
        status = 'online',
        ip = ?,
        agent_version = COALESCE(?, agent_version)
    WHERE id = ?
  `).run(req.ip || req.device.ip, agentVersion, req.device.id);

  db.prepare('INSERT INTO heartbeats (device_id, cpu_pct, mem_pct, uptime_s) VALUES (?, ?, ?, ?)')
    .run(req.device.id, cpu, mem, uptime);

  // Cheap retention: keep ~48h of heartbeat history.
  if (Math.random() < 0.02) {
    db.prepare("DELETE FROM heartbeats WHERE created_at < datetime('now', '-2 days')").run();
  }

  return res.json({ ok: true });
});

// ---------------------------------------------------------------------------
// POST /api/v1/events  {events:[{type, ts, severity, data}]}  max 200/batch
// ---------------------------------------------------------------------------
const insertEventStmt = db.prepare(
  'INSERT INTO events (device_id, type, severity, data) VALUES (?, ?, ?, ?)'
);
const insertAlertStmt = db.prepare(
  'INSERT INTO alerts (device_id, event_id, rule, title, severity, status) VALUES (?, ?, ?, ?, ?, ?)'
);

router.post('/events', (req, res) => {
  const body = req.body || {};
  const events = body.events;
  if (!Array.isArray(events)) {
    return res.status(400).json({ error: 'invalid_payload', detail: 'events must be an array' });
  }
  if (events.length > MAX_BATCH) {
    return res.status(400).json({ error: 'batch_too_large', max: MAX_BATCH });
  }

  const thresholds = getThresholds(req.device.org_id);
  let accepted = 0;
  let alertsCreated = 0;

  const ingest = db.transaction((batch) => {
    for (const raw of batch) {
      if (!raw || typeof raw !== 'object') continue;
      const type = typeof raw.type === 'string' ? raw.type.trim().slice(0, 128) : '';
      if (!type) continue;

      const severity = SEVERITIES.has(raw.severity) ? raw.severity : 'info';
      const data = (raw.data && typeof raw.data === 'object' && !Array.isArray(raw.data)) ? raw.data : {};
      if (raw.ts !== undefined && data.agent_ts === undefined) data.agent_ts = raw.ts;

      const evt = { type, severity, data };
      const info = insertEventStmt.run(req.device.id, type, severity, JSON.stringify(data));
      accepted++;

      const alert = evaluateEvent(evt, thresholds);
      if (alert) {
        const alertInfo = insertAlertStmt.run(req.device.id, info.lastInsertRowid, alert.rule, alert.title, alert.severity, 'open');
        alertsCreated++;

        // Fire-and-forget email notification.
        setImmediate(() => {
          try {
            sendAlertEmail({
              orgId: req.device.org_id,
              alert: { id: alertInfo.lastInsertRowid, rule: alert.rule, title: alert.title, severity: alert.severity },
              device: { id: req.device.id, hostname: req.device.hostname },
              event: evt,
            });
          } catch (err) {
            console.error('[fortrix] alert email hook failed:', err.message);
          }
        });
      }
    }
  });

  ingest(events);

  // Event traffic also proves liveness.
  db.prepare("UPDATE devices SET last_seen = datetime('now'), status = 'online' WHERE id = ?")
    .run(req.device.id);

  return res.json({ accepted, alerts_created: alertsCreated });
});

// ---------------------------------------------------------------------------
// Agent version config (per-device, with global fallback)
// ---------------------------------------------------------------------------
router.get('/config', (req, res) => {
  return res.json({
    thresholds: getThresholds(req.device.org_id),
    intervals: getIntervals(),
    agent_version: req.device.agent_version || '0.0.0',
  });
});

// GET /api/v1/agent/version — check for available update
router.get('/agent/version', (req, res) => {
  const current = (typeof req.query.current === 'string') ? req.query.current.slice(0, 32) : '';
  const platform = osToPlatform(req.device.os);
  const arch = req.device.arch || 'amd64';

  const latest = db.prepare(`
    SELECT version, url, sha256, release_notes
    FROM agent_versions
    WHERE platform = ? AND arch = ?
    ORDER BY created_at DESC
    LIMIT 1
  `).get(platform, arch);

  if (!latest || !current) {
    return res.json({ update_available: false, current, latest: latest ? latest.version : null });
  }

  // Simple semver-like comparison: split, compare each segment.
  const newer = compareVersions(latest.version, current) > 0;
  return res.json({
    update_available: newer,
    current,
    latest: latest.version,
    url: newer ? latest.url : undefined,
    sha256: newer ? latest.sha256 : undefined,
    release_notes: newer ? latest.release_notes : undefined,
  });
});

// ---------------------------------------------------------------------------
// Remote commands — agent polls for pending, reports results
// ---------------------------------------------------------------------------
router.get('/commands/pending', (req, res) => {
  const cmds = db.prepare(
    "SELECT id, command_type, payload FROM device_commands WHERE device_id = ? AND status = 'pending' ORDER BY created_at ASC LIMIT 5"
  ).all(req.device.id);
  if (cmds.length > 0) {
    const ids = cmds.map(function(c) { return c.id; });
    db.prepare("UPDATE device_commands SET status = 'sent' WHERE id IN (" + ids.map(function() { return '?'; }).join(',') + ")")
      .run.apply(null, ids);
  }
  return res.json(cmds);
});

router.post('/commands/:id/result', (req, res) => {
  var id = req.params.id;
  var body = req.body || {};
  var cmd = db.prepare("SELECT * FROM device_commands WHERE id = ? AND device_id = ?").get(id, req.device.id);
  if (!cmd) return res.status(404).json({ error: 'not_found' });
  var finalStatus = body.status === 'success' ? 'success' : 'failed';
  db.prepare("UPDATE device_commands SET status = ?, result = ?, executed_at = datetime('now') WHERE id = ?")
    .run(finalStatus, String(body.result || '').slice(0, 4000), id);
  return res.json({ ok: true });
});
function compareVersions(a, b) {
  const pa = a.split('.').map(Number);
  const pb = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}
function osToPlatform(os) {
  if (!os) return 'windows';
  const s = os.toLowerCase();
  if (s.includes('windows')) return 'windows';
  if (s.includes('darwin') || s.includes('mac')) return 'darwin';
  return 'linux';
}

module.exports = router;
